/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalhopraticoid;

import static com.mycompany.trabalhopraticoid.Pais.criaPais;
import java.io.IOException;
import java.util.ArrayList;
import net.sf.saxon.s9api.SaxonApiException;

/**
 *  Dinis Meireles de Sousa Falcão | 2020130403
 *  Telmo Eduardo Fonseca Silva | 2019127444
 */
public class TrabalhoPraticoID {

    public static void main(String[] args) throws IOException, SaxonApiException {
        System.out.println("Hello World!");
        
        JFrame app = new JFrame();
        app.setVisible(true);
    }
}
